#include<stdio.h>
main() {

	biggest2();
	biggest3();
	factorial();
	reverse();
	fibonacci();
	palindrome();
	sum2num();
	sorting();
}
